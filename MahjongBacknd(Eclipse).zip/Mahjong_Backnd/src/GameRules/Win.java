package GameRules;

import Players.Computers;
import Players.Player;

public class Win {
    public Win(Player[] players, Computers[] computers) {

    }
}
