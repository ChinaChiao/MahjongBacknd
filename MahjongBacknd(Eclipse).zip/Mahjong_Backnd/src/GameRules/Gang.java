package GameRules;

import Mahjong.MahjongTile;
import Players.Computers;
import Players.Player;

public class Gang {
    public Gang(MahjongTile discardTile, Player[] players, Computers[] computers) {

    }
}
