package GameRules;

import Mahjong.MahjongTile;
import Players.Computers;
import Players.Player;

public class Peng {
    public Peng(MahjongTile discardTile, Player[] players, Computers[] computers) {

    }
}
